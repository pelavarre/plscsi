(This file was readme.txt sometime after Monday, July 8, 2002 began.)

Please do backup your hard drive before you run PLScsi, rather than living thru the pain of having PLScsi teach you that you need to backup more often.

For example, accidentally entering just the 13 chars of the command `plscsi -pwx04` might smash every connected SCSI drive for you. We're not sure just because we haven't tried that much.
