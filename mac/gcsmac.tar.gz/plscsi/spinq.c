/* spinq.c */

#include "xscsi.h"

int main(int argc, char * argv[])
{
	int rc = 0;
	int ix = 0;
	struct sp * sp = (struct sp *) calloc(1, sizeof_struct_sp());
	int max = 0x24; /* x24 = x 8 + 10 + 8 + 4 */
	int fudge = 0x123; /* at least one */
	char * data = (char *) calloc(1, max + fudge);

	assert(sp != NULL);
	assert(data != NULL);
	assert(((char *) sp) < data);

	fprintf(stderr, "compiled since %s %s\n", __DATE__, __TIME__);

	--argc; ++argv;
	if (argc <= 0) {
		fprintf(stderr, "usage: ./spinq $device_name...\n");
		return -__LINE__;
	}

	for (ix = 0; ix < argc; ++ix) {
		char const * st = argv[ix];
		if (sp_open(sp, st) < 0) {
			sp_perror(sp, "sp_open");
		} else {
			char sense[USUAL_SENSE];
			sp_sense(sp, sense, sizeof sense);
			sp_late(sp, USUAL_S, 0);

			sp_cdb(sp, "\x12\x00\x00\x00\x24\x00", 6);
			rc |= sp_read(sp, &data[0], max);
			if (rc != 0) {
				sp_perror(sp, "sp_read");
			} else {

				data[max] = '\0';
				printf("%s: %s\n", st, &data[8]);
			}
		}
	}

	return rc;
}

/* end of file */
