plscsi/ReadMe.txt

difficulties:

thirteen cases
lost unit attentions
open and close overhead
too many parameters
	too many error paths
caveats


see also: http://members.aol.com/plscsi/
see also: SCSI pass thru blog

grep FIXME will share with you our guess of the future.

FIXME: quote normal results
FIXME: set all eol = cr lf because Mac/ Linux copes with alien eol
FIXME: list files

------ results last seen at my desk:

$
cd plscsi
$
ls
ReadMe.txt      mac.makefile    spinq.c
configure       mscsi.c         xscsi.h
$
./configure
+ uname -s
+ grep Darwin
+ cp mac.makefile Makefile
$
make
gcc -g -Wall -W -o spinq mscsi.c spinq.c \
        -framework IOKit -framework CoreFoundation
$
./spinq 2 1 0
compiled since Jul 12 2004 15:32:46
sp_open: -4 = xFFFFFFFC
sp_open: -4 = xFFFFFFFC
0: MATSHITACD-RW  CW-8121  AA17
$
make clean
rm Makefile spinq
$

