/* plscsi/mscsi.c
 *
 * Pass arbitrary SCSI thru Mac OS X from "xscsi.h",
 * via SCSITaskInterface as a STUC (SCSI Task User client),
 * much as Apple's Authoring/UnixTool/AuthoringUnitTestUnixTool.c does,
 * since Mac OS X 10.3.2 or so.
 *
 * Work left to the client:
 *
 *	Name devices by op x12 "INQUIRY" data.
 *	Limit sense and limit time after opening the device.
 *	Hint at the mis/alignment of struct, cdb, sense, and data.
 *	Close before exit via main return, stdlib exit, or SIGINT.
 *	Avoid null pointers and negative lengths.
 *
 * Wishes:
 *
 *	FIXME: Discover precisely what is an Apple SCSITaskAuthoringDevice.
 *	FIXME: Pass thru the Apple mmcdi subset of SCSI without excl. access.
 *	FIXME: Count bytes auto sensed, rather than claiming all requested.
 *
 * Limits:
 *
 *	Automount implicitly after close via ReleaseExclusiveAccess.
 *	Expect only one of only Hn Hi Ho via SetScatterGatherEntries.
 *	Maybe surprisingly write thru (char const *) when D != Hi.
 *
 *	Limit CDB bytes to xFF.
 *	Limit data bytes to the max advance virtual allocation.
 *	Limit sense bytes to xFF.
 *
 * References:
 *
 *	See end of file.
 */

/* Link with standard C libraries, often via /usr/include. */

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Link with Unix C libraries, often via /usr/include/.  */

#include <unistd.h>

/* Link with clients. */

#include "xscsi.h"

/* Link with local C libraries, often via:
 * /System/Library/Frameworks/CoreFoundation.framework/Headers/CoreFoundation.h
 * /System/Library/Frameworks/IOKit.framework/Headers/IOKitLib.h
 * /System/Library/Frameworks/IOKit.framework/Headers/scsi/SCSITaskLib.h
 */

#include <CoreFoundation/CoreFoundation.h> /* gcc -framework CoreFoundation */
#include <IOKit/IOKitLib.h> /* gcc -framework IOKit */
#include <IOKit/scsi/SCSITaskLib.h>

/* Declare the struct of private ioctl parameters. */

struct sp;

/* Define the struct of ioctl parameters.
 * Say how to speak SCSI with mis/aligned struct, cdb, sense, and data.
 */

struct sp
{
	void * cdb;	/* Name the CDB bytes copied out. */
	int cdb_min;	/* Ask to copy out enough bytes of CDB. */
	void * sense;	/* Name the sense bytes in. */
	int sense_max;	/* Limit sense bytes copied in. */
	int ms;		/* Limit time per CDB. */

	void * data;	/* Name the read data in or the write data out. */
	int max;	/* Limit data bytes copied in or out. */
	int hnio;	/* Expect one of Hn Hi Ho. */

	IONotificationPortRef inpr; /* Open enough layers to talk. */
	io_iterator_t ii;
	io_service_t ios;
	IOCFPlugInInterface ** iocfpii;
	MMCDeviceInterface ** mmcdi;
	SCSITaskDeviceInterface ** woea_stdi; /* without ExclusiveAccess */
	SCSITaskDeviceInterface ** stdi; /* with ExclusiveAcess */
	SCSITaskInterface ** sti;

	int copied;	/* Count the data bytes copied. */
	int rc;		/* Name the last result. */
};

/* Calculate the length, without naming the members,
 * of the struct of ioctl parameters.
 *
 * Note: Win XP/ ME/ Dos grows the struct to include CDB, sense, and/ or data.
 */

size_t sizeof_struct_sp(void)
{
	return sizeof (struct sp);
}

/* Exit after printing why. */

static void exits(char const * st, char const * file, int line)
{
	if (*st != '\0') {
		fprintf(stderr, "%s: ", st);
	}
	fprintf(stderr, "%d line %s file\n", line, file);
	exit(-line);
}

/* Close every opened layer, in reverse of the order opened.
 * Gracefully do nothing if called repeatedly.
 * Forget everything.
 *
 * FIXME: Notice if close fails via destroy or release failing.
 */

void sp_close(struct sp * sp)
{
	if (sp->sti != NULL) {
		(*sp->sti)->Release(sp->sti);
		sp->sti = NULL;
	}
	if (sp->stdi != NULL) {
		(*sp->stdi)->ReleaseExclusiveAccess(sp->stdi);
		sp->stdi = NULL;
	}
	if (sp->woea_stdi != NULL) {
		(*sp->woea_stdi)->Release(sp->woea_stdi);
		sp->woea_stdi = NULL;
	}
	if (sp->mmcdi != NULL) {
		(*sp->mmcdi)->Release(sp->mmcdi);
		sp->mmcdi = NULL;
	}
	if (sp->iocfpii != NULL) {
		IODestroyPlugInInterface(sp->iocfpii);
		sp->iocfpii = NULL;
	}
	if (sp->ios != 0) {
		IOObjectRelease(sp->ios);
		sp->ios = 0;
	}
	if (sp->ii != 0) {
		IOObjectRelease(sp->ii);
		sp->ii = 0;
	}
	if (sp->inpr != 0) {
		IONotificationPortDestroy(sp->inpr);
		sp->inpr = 0;
	}
	memset(sp, '\0', sizeof *sp);
}

/* Close and return trouble, but also pass that trouble to sp_error. */

static int sp_close_rc(struct sp * sp, int rc)
{
	sp_close(sp);
	sp->rc = rc;
	return rc;
}

/* Zero the struct, except leave it closed or open. */

void sp_reconnect(struct sp * sp)
{
	struct sp auto_sp;
	struct sp * zsp = &auto_sp;
	memset(zsp, '\0', sizeof *zsp);

	zsp->inpr = sp->inpr;
	zsp->ii = sp->ii;
	zsp->ios = sp->ios;
	zsp->iocfpii = sp->iocfpii;
	zsp->mmcdi = sp->mmcdi;
	zsp->woea_stdi = sp->woea_stdi;
	zsp->stdi = sp->stdi;
	zsp->sti = sp->sti;

	*sp = *zsp;
	sp->hnio = kSCSIDataTransfer_NoDataTransfer; /* x00 Hn maybe */
}

/* Open and return zero, else return trouble.
 * Pass the value returned to sp_perror.
 * First close if open already.
 *
 * FIXME: Open a BSD device name.
 *
 * To assign Mac OS X device names without first counting the devices, name
 * the devices 0 1 2 ... rather than 2 1 0 ....
 *
 * Hope to reproduce the same names after any repeat of a slow sequence of boot
 * and plug in, also after zero or more unplugs in reverse order of plug in.
 * Regret that failures of ObtainExclusiveAccess may sparsely populate the
 * 0 1 2 ... name space.  For example, 0 and 2 may open even if 1 does
 * not.
 *
 * Regret that sscanf %d accepts more than printf %d produces.
 */

int sp_open(struct sp * sp, char const * name)
{
	int ix = 0;
	if (sscanf(name, "%d", &ix) != 1) {
		return sp_close_rc(sp, -1);
	}
	return sp_open_ix(sp, ix);
}

/* Open and return zero, else return trouble.
 * Pass the value returned to sp_perror.
 * First close if open already.
 *
 * Open just the n-th match of:
 *
 *	<dict>
 *		<key>IOPropertyMatch</key>
 *		<dict>
 *			<key>SCSITaskDeviceCategory</key>
 *			<string>SCSITaskAuthoringDevice</string>
 *		</dict>
 *	</dict>
 *
 * Touch the other matches if need be.  Seemingly that does no harm.
 *
 * FIXME: Notice if CFDictionary fails.
 * FIXME: Notice if IOObjectRelease fails.
 */

int sp_open_ix(struct sp * sp, int name)
{
	IOReturn ior = 0;
	CFMutableDictionaryRef iopm_cfmdr = NULL;
	CFMutableDictionaryRef stdc_cfmdr = NULL;
	void ((*after_first_match)(void *, io_iterator_t)) = NULL;
	int ix = 0;
	SInt32 score = 0;
	HRESULT hr = S_OK;

	/* Begin again. */

	sp_close(sp);

	/* Connect with zero or more devices. */

	sp->inpr = IONotificationPortCreate(kIOMasterPortDefault);
	if (sp->inpr == 0) {
		return sp_close_rc(sp, -2);
	}

	stdc_cfmdr = CFDictionaryCreateMutable(
		kCFAllocatorDefault,
		0,
		&kCFTypeDictionaryKeyCallBacks,
		&kCFTypeDictionaryValueCallBacks);

	iopm_cfmdr = CFDictionaryCreateMutable(
		kCFAllocatorDefault,
		0,
		&kCFTypeDictionaryKeyCallBacks,
		&kCFTypeDictionaryValueCallBacks);

	CFDictionarySetValue(
		stdc_cfmdr,
		CFSTR(kIOPropertySCSITaskDeviceCategory),
		CFSTR(kIOPropertySCSITaskAuthoringDevice));

	CFDictionarySetValue(
		iopm_cfmdr,
		CFSTR(kIOPropertyMatchKey),
		stdc_cfmdr);

	ior = IOServiceAddMatchingNotification(sp->inpr,
		kIOFirstMatchNotification,
		iopm_cfmdr, after_first_match, NULL, &sp->ii);
	if (ior != kIOReturnSuccess) {
		return sp_close_rc(sp, -3);
	}

	/* Disconnect all but the selected device. */

	ix = 0;
	for (;;) {
		io_service_t ios = IOIteratorNext(sp->ii);
		if (ios == 0) {
			break;
		}
		if (ix == name) {
			sp->ios = ios;
		} else {
			IOObjectRelease(ios);
		}
		++ix;
	}

	/* Fail unless one device remains connected. */

	if (sp->ios == 0) {
		return sp_close_rc(sp, -4);
	}

	/* Open iocfpii. */

	ior = IOCreatePlugInInterfaceForService(sp->ios,
		kIOMMCDeviceUserClientTypeID, kIOCFPlugInInterfaceID,
		&sp->iocfpii, &score);
	if ((ior != kIOReturnSuccess) || (sp->iocfpii == NULL)) {
		return sp_close_rc(sp, -5);
	}

	/* Open mmcdi. */

	hr = (*sp->iocfpii)->QueryInterface(sp->iocfpii,
		CFUUIDGetUUIDBytes(kIOMMCDeviceInterfaceID),
		(LPVOID) &sp->mmcdi);
	if ((hr != S_OK) || (sp->mmcdi == NULL)) {
		return sp_close_rc(sp, -6);
	}

	/* Open stdi. */

	sp->woea_stdi = (*sp->mmcdi)->GetSCSITaskDeviceInterface(sp->mmcdi);
	if (sp->woea_stdi == NULL) {
		return sp_close_rc(sp, -7);
	}

	/* Make stdi exclusive to allow CreateSCSITask. */

	ior = (*sp->woea_stdi)->ObtainExclusiveAccess(sp->woea_stdi);
	if (ior != kIOReturnSuccess) {
		return sp_close_rc(sp, -8);
	}
	sp->stdi = sp->woea_stdi;

	/* Open sti (16 may be max per boot). */

	sp->sti = (*sp->stdi)->CreateSCSITask(sp->stdi);
	if (sp->sti == NULL) {
		return sp_close_rc(sp, -9);
	}

	/* Choose default options. */

	sp_reconnect(sp); /* unnecessary if close left defaults correct */

	/* Succeed. */

	return 0;
}

/* Complain to stderr. */

void sp_perror(struct sp * sp, char const * st)
{
	fprintf(stderr, "%s: %d = x%X\n", st, sp->rc, sp->rc);
}

/* Hint from where and how much cdb to copy out, return where.
 * Succeed else do not return.
 *
 * Note: Win XP/ ME/ DOS aligns the cdb to the struct.
 */

char * sp_cdb(struct sp * sp, char * cdb, int min)
{
	if (MAX_CDB < min) exits("large", __FILE__, __LINE__);
	sp->cdb = cdb;
	sp->cdb_min = min;
	return cdb;
}

/* Hint to/ from where and how much data to copy in/ out, return where.
 * Hint before deciding to copy in or out.
 * Succeed else do not return.
 *
 * Note: Win XP SPT (not SPTD) places the data past but near the struct.
 */

char * sp_data(struct sp * sp, char * data, int max)
{
	sp->data = data;
	sp->max = max;
	return data;
}

/* Hint to where and how much sense to copy in, return where.
 * Succeed else do not return.
 *
 * Note: Win XP places the sense past but near the struct.
 * Note: DOS aligns the sense to the cdb.
 */

char * sp_sense(struct sp * sp, char * sense, int max)
{
	if (MAX_SENSE < max) exits("large", __FILE__, __LINE__);
	sp->sense = sense;
	sp->sense_max = max;
	return sense;
}

/* Hint when to time out and reset, return rounded ns past the last s.
 * Succeed else do not return.
 *
 * Note: Win ME/ DOS makes time difficult to limit.
 */

int sp_late(struct sp * sp, int s, int ns)
{
	int ms = ((s * 1000) + ((ns + 999999) / 1000 / 1000));
	if ((ms / 1000) != s) exits("large", __FILE__, __LINE__);
	sp->ms = ms;
	return ((sp->ms % 1000) * 1000 * 1000);
}

/* Zero all but the least significant set bit of a mask,
 * portably across platforms.
 */

static int lsb(int mask)
{
	return (mask & -mask);
}

/* Construct an sp_read/ sp_write exit int from bits of auto sense,
 * without deciding sp_error.
 */

static int int_from_sense(char const * chars, int length)
{
	int rc = SP_THRU | SP_SENSE; /* unintelligible sense */

	/* Require minimal sense. */

	if (2 < length) {
		int sk = (chars[2] & 0x0F);
		int response_code = (chars[0] & 0x7F);
		if ((response_code == 0x70) || (response_code == 0x71)) {
			rc &= ~SP_SENSE; /* intelligible sense */

			/* Distinguish x70 Current vs. other sense. */

			if (response_code != 0x70) {
				rc |= SP_DEFERRED;
			}

			/* Pass back SK. */

			rc |= (sk * lsb(SP_SK));

			/* Interpret additional length, not quite as t10. */

			if (7 < length) {
				int al = (chars[7] & 0xFF);
				if (al != 0x00) {
					int max = (7 + 1 + al);
					if (max < length) {
						length = max;
					}
				}
			}

			/* Pass back ASC and ASCQ. */

			if (0xC < length) {
				int asc = (chars[0xC] & 0xFF);
				rc |= (asc * lsb(SP_ASC));
			}
			if (0xD < length) {
				int ascq = (chars[0xD] & 0xFF);
				rc |= (ascq * lsb(SP_ASCQ));
			}
		}
	}
	return rc;
}

/* Pass SCSI thru.
 * Return zero, else positive residue, else negative trouble.
 * Pass the value returned to sp_perror.
 */

int sp_speak(struct sp * sp)
{
	SCSITaskInterface ** sti = sp->sti;
	IOReturn ior = 0;
	IOVirtualRange iovr[1]; /* indeterminate */
	SCSIServiceResponse ssr = kSCSIServiceResponse_Request_In_Process;
	SCSITaskStatus sts = kSCSITaskStatus_No_Status;
	UInt64 length = 0;
	int residue = 0;
	int rc;

	/* Fail if not open. */

	sp->rc = rc = -1;
	if (sti == NULL) {
		return rc;
	}

	/* Ask to copy out the cdb. */

	ior = (*sti)->SetCommandDescriptorBlock(sti, sp->cdb, sp->cdb_min);
	if (ior != kIOReturnSuccess) {
		return rc;
	}

	/* Ask to copy the data in or out or not. */

	memset(&iovr, '\0', sizeof iovr);
	iovr[0].address = (IOVirtualAddress) sp->data;
	iovr[0].length  = sp->max;
	ior = (*sti)->SetScatterGatherEntries(sti,
		&iovr[0], LENGTHOF(iovr), sp->max, sp->hnio);
	if (ior != kIOReturnSuccess) {
		return rc;
	}

	/* Ask to copy the sense in.  May be (NULL, 0). */

	ior = (*sti)->SetAutoSenseDataBuffer(sti, sp->sense, sp->sense_max);
	if (ior != kIOReturnSuccess) {
		return rc;
	}

	/* Ask to time out.  May be 0. */

	ior = (*sti)->SetTimeoutDuration(sti, sp->ms);
	if (ior != kIOReturnSuccess) {
		return rc;
	}

	/* Speak. */

	ior = (*sti)->ExecuteTaskSync(sti, sp->sense, &sts, &length);
	sp->copied = (int) length;
	if (ior != kIOReturnSuccess) {
		return rc;
	}
	ior = (*sti)->GetSCSIServiceResponse(sti, &ssr);
	if (ior != kIOReturnSuccess) {
		return rc;
	}

	/* Compress much into the exit int. */

	residue = (sp->max - (int) length);

	if (ssr != kSCSIServiceResponse_TASK_COMPLETE) {
		rc = -1;
	} else if ((UInt64) sp->max < length) {
		rc = -1;
	} else if (sts != kSCSITaskStatus_GOOD) {
		if (sts != kSCSITaskStatus_CHECK_CONDITION) {
			rc = SP_THRU;
			rc |= SP_SENSE_THRU; /* sense not counted */
		} else {
			int sense_enough = sp->sense_max;
			rc = SP_THRU;
			rc |= int_from_sense(sp->sense, sense_enough);
			if (0 != residue) {
				rc |= SP_RESIDUE;
			}
		}
	} else {
		rc = residue; /* zero if ok else positive residue */
	}

	sp->rc = rc;
	return rc;
}

/* Pass SCSI thru and copy zero or more bytes of data in. */

int sp_read(struct sp * sp, char * to, int max)
{
	sp_data(sp, to, max);
	sp->hnio = kSCSIDataTransfer_FromTargetToInitiator; /* x01 Hi maybe */
	return sp_speak(sp);
}

/* Pass SCSI thru and copy zero or more bytes of data out. */

int sp_write(struct sp * sp, char const * from, int max)
{
	char * data = (char *) from; /* not formally const */
	sp_data(sp, data, max);
	sp->hnio = kSCSIDataTransfer_FromInitiatorToTarget; /* x02 Ho maybe */
	return sp_speak(sp);
}

/* Get the last length of data copied in.
 * Guess max if unknown, zero if garbled.
 *
 * FIXME: Why EXC_BAD_ACCESS from GetRealizedDataTransferCount.
 */

int sp_data_enough(struct sp * sp)
{
	return sp->copied;
}

/* Get the last length of sense copied in.
 * Guess max if unknown, zero if garbled.
 */

int sp_sense_enough(struct sp * sp)
{
	int rc = sp->rc;
	if (rc < 0) {
		if ((sp->rc & SP_SENSE) == 0) {
			return sp->sense_max;
		}
	}
	return 0;
}

/* References:
 *
 * To click thru much of this,
 * you may need an "Apple ID" such as jdoe@isp.com.
 * 
 * Search:
 * 
 *	http://www.google.com/search?as_q=SetCommandDescriptorBlock&as_sitesearch=developer.apple.com
 * 
 * Examples:
 * 
 *	/Developer/Examples/IOKit/scsi/SCSITaskLib/
 *	/Developer/Examples/IOKit/scsi/SCSITaskLib/Authoring/UnixTool/AuthoringUnitTestUnixTool.c
 * 
 *	http://www.opensource.apple.com/darwinsource/
 *	http://www.opensource.apple.com/darwinsource/10.3.2/IOSCSIArchitectureModelFamily-131.0.4/TestTools/STUC/UnitTests/Authoring/UnixTool/AuthoringUnitTestUnixTool.c
 *	http://www.opensource.apple.com/darwinsource/10.3.3/IOSCSIArchitectureModelFamily-133.3.1/TestTools/STUC/STUCLeakFinder/STUCLeakFinder.c
 * 
 * Declarations:
 * 
 *	/System/Library/Frameworks/IOKit.framework/Headers/
 *	/System/Library/Frameworks/IOKit.framework/Headers/scsi/SCSICmds_REQUEST_SENSE_Defs.h
 * 
 *	http://www.opensource.apple.com/darwinsource/
 *	http://www.opensource.apple.com/darwinsource/10.3.3/IOSCSIArchitectureModelFamily-133.3.1/IOSCSIArchitectureModel/SCSICmds_REQUEST_SENSE_Defs.h
 * 
 * Docs:
 * 
 *	http://developer.apple.com/documentation/Darwin/
 *	http://developer.apple.com/documentation/Darwin/Reference/IOKit/SCSITaskLib/Classes/SCSITaskInterface/Functions/Functions.html
 *
 * Blogs:
 *
 *	Subject: Mac OS X SCSI Pass Thru Documented Where
 *	http://plavarre.blog-city.com/read/529000.htm
 */

/* end of file */
