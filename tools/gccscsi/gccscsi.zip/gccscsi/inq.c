/* inq.c = op x12 Inquiry */

#include "gccscsi.h"

void inq(void) {
	i(0x24); y("\x12\x00\x00\x00\x24\x00"); // Inquiry
	fprintf(stderr, "%s\n", &(chars())[8]);
}

int main(int argc, char *argv[]) {

	--argc; ++argv;
	if (!(0 < argc)) qui();

	v();
	ds(argv[0]);
	inq();
	q();
	return 0;
}

