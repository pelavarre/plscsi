/* tur.c = op x00 Test Unit Ready */

#include "gccscsi.h"

void tur(void) {
	y("\x00\x00\x00\x00\x00\x00"); // Test Unit Ready
}

int main(int argc, char *argv[]) {

	--argc; ++argv;
	if (!(0 < argc)) qui();

	v();
	ds(argv[0]);
	tur();
	q();
	return 0;
}

