/* rc.c = op x25 Read Capacity */

#include "gccscsi.h"

void rc(void) {
	char * chars = chars();
	int h = 0;
	int w = 0;

	i(8); y("\x25\x00" "\x00\x00\x00\x00" "\x00" "\x00\x00" "\x00" ); // Read Capacity

	LIL(h, 3) = chars[0];
	LIL(h, 2) = chars[1];
	LIL(h, 1) = chars[2];
	LIL(h, 0) = chars[3];
	++h;

	LIL(w, 3) = chars[4];
	LIL(w, 2) = chars[5];
	LIL(w, 1) = chars[6];
	LIL(w, 0) = chars[7];

	h_is(h);
	w_is(w);
}

int main(int argc, char *argv[]) {

	--argc; ++argv;
	if (!(0 < argc)) qui();

	v();
	ds(argv[0]);
	rc();
	q();
	return 0;
}

