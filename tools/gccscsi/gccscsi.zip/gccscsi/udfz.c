/* udfz.c = write just enough zeroes to undo anyone's mkudffs */

#include "gccscsi.h"

void inq(void) {
	i(0x24); y("\x12\x00\x00\x00\x24\x00"); // Inquiry
	fprintf(stderr, "%s\n", &(chars())[8]);
}

void tur(void) {
	y("\x00\x00\x00\x00\x00\x00"); // Test Unit Ready
	printf("Unit Ready.\n");
}

void up(void) {
	y("\x1B\x00\x00\x00\x01\x00"); // Start Unit
	printf("Start Unit ok.\n");
}

void rc(void) {
	char * chars = chars();
	int h = 0;
	int w = 0;

	i(8); y("\x25\x00" "\x00\x00\x00\x00" "\x00" "\x00\x00" "\x00" ); // Read Capacity

	LIL(h, 3) = chars[0];
	LIL(h, 2) = chars[1];
	LIL(h, 1) = chars[2];
	LIL(h, 0) = chars[3];
	++h;

	LIL(w, 3) = chars[4];
	LIL(w, 2) = chars[5];
	LIL(w, 1) = chars[6];
	LIL(w, 0) = chars[7];

	h_is(h);
	w_is(w);
}

void wr(int first, int count) {
	char * chars = chars();
	char cdb[] = "\x2A\x00" "\x12\x34\x56\x78" "\x00" "\x12\x34" "\x00"; // Write 10
	int length = (count * w());
	if ((count < 0) || (0xFFFF < count)) qui();
	if ((length < 0) || (chars_max_length() < count)) qui();

	memset(chars, '\0', length);

	cdb[2] = LIL(first, 3);
	cdb[3] = LIL(first, 2);
	cdb[4] = LIL(first, 1);
	cdb[5] = LIL(first, 0);

	cdb[7] = LIL(count, 1);
	cdb[8] = LIL(count, 0);

	o(length); y(cdb);
}

static int minint(int i1, int i2) {
	if (i1 < i2) return i1;
	return i2;
}

void zap(int where, int count) {
	int sliver = ((64 * 0x400) / w());
	int index = 0;
	for (index = 0; index < count; index += sliver) {
		int some = minint(count - index, sliver);
		wr(where, some);
		where += some;
	}
}

int main(int argc, char *argv[]) {

	--argc; ++argv;
	if (!(0 < argc)) qui();

	v();
	ds(argv[0]);
	inq();
	tur(); up(); rc();

        zap(0, 64);
        zap(256, 32);
        zap(512, 32);
        zap(h() - 512 - 32, 512 + 32);

//	q();
	return 0;
}

