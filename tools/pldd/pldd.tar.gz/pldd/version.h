#define VERSION "Friday, September 19, 2003\n"

