/* pldd.h
 *
 * Help all the pldd *.c* link together.
 *
 * Bugs include:
 *
 * 	Define LIL(I, N) incorrectly if cpu is big-endian.
 */

#ifdef __cplusplus
extern "C" {
#endif

#define DD_LLONG_MAX 9223372036854775807LL /* = x7FFF:FFFF:FFFF:FFFF */

#if 0
#define LIL(I, N) (((char *)&(I))[(sizeof (I)) - (N)])
#else
#define LIL(I, N) (((char *)&(I))[(N)])
#endif

#define T() fprintf(stderr, "file %s line %d\n", __FILE__, __LINE__);

struct dd_file;

#define DD_NULL ((struct dd_file *) NULL)
extern struct dd_file * dd_in(void);
extern struct dd_file * dd_out(void);

extern struct dd_file * dd_open_rb(char const * fn);
extern struct dd_file * dd_open_wb(char const * fn);
extern void dd_close(struct dd_file * ddf);

extern void dd_seek_set(struct dd_file * ddf, long long offset);
extern size_t dd_read(char * chars, size_t sz, struct dd_file * ddf);
extern size_t dd_write(char const * chars, size_t sz, struct dd_file * ddf);

extern int dd_getms(void);

extern void dd_set_verbose(int v);

extern int sp_say(int dev, char const * cdbChars, int cdbLength, char * outChars, char * inChars, int maxLength);
extern int sp_close(int dev);
extern int sp_open(char const * name);

extern void sp_dump(char const * chars, int length);

#ifdef __cplusplus
}
#endif

/* end of file */

