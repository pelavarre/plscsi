/* pldd.c
 *
 * Copy bytes at the command line a la Unix `dd`.
 *
 * Count but do not time or print the copies.
 * Accept hex arguments, not just decimal.
 * Die gracefully if asked to count past LLONG_MAX.
 *
 * Bugs include:
 *
 *      Abbreviate if=/dev/zero without abbreviating if=/dev/urandom
 * 	Lose count of copies if halted via Ctrl+C.
 * 	Copy with one thread, not two.
 *	Die when bs= exceeds INT_MAX.
 *	Do not guess whether K M T G means Ki Mi Ti Gi or not.
 *	Always exit(0).
 *
 * See also: man dd
 * See also: http://lxr.linux.no/source/Documentation/CodingStyle
 */

#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "pldd.h"
#include "version.h"

static char * ifn = ""; /* if=FILE */
static struct dd_file * ifile = DD_NULL; /* name open input file */
static long long skip = 0; /* skip=BLOCKS */

static char * ofn = ""; /* of=FILE */
static struct dd_file * ofile = DD_NULL; /* name open output file */
static long long seek = 0; /* seek=BLOCKS */

static long long bs = 0x200; /* bs=BYTES */
static char * chars = NULL; /* name bytes copied */
static long long count = -1; /* count=BLOCKS */

static long long sbs = 0; /* sbs=BYTES for skip= and seek= */
static long long ms = 0; /* ms=MILLISECONDS */
static int verbose = 0; /* -v */
static int forced = 0; /* -f = forced fuzzy following full ... */

static long long tried = 0; /* count bytes tried to copy */
static long long copied = 0; /* count bytes copied */

/* Exit quietly but not silently after a syntax error. */

static void exitConcise(void)
{
	fprintf(stderr, "command line unintelligible, try: dd --help\n");
	exit(-__LINE__);
}

/* Exit noisily for --help. */

static void exitVerbose(void)
{
	fprintf(stderr,
/* "456789_123456789_123456789_123456789_123456789_123456789_123456 */
"\n"
"pldd - Copy bytes\n"
"\n"
"  if=FILE               name input other than standard input\n"
"  if                    copy out zeroes like if=/dev/zero in Unix\n"
"  skip=BLOCKS           seek before reading\n"
"\n"
"  of=FILE               name output other than standard output\n"
"  of                    copy and discard like of=/dev/null in Unix\n"
"  seek=BLOCKS           seek before writing\n"
"\n"
"  bs=BYTES              bytes/block (suffixes k m g mean Ki Mi Gi)\n"
"  sbs=BYTES             bytes per skip/seek block (if not same as bs)\n"
"  count=BLOCKS          blocks per copy\n"
"  ms=MILLISECONDS       max milliseconds per copy\n"
"\n"
"  --version             print version\n"
"  --help                print this help\n"
"  -f                    copy past error/eof (works best with count=)\n"
"  -v                    trace read/ write (but not open/ close/ seek)\n"
"\n"
"  See also: man dd\n"
"\n"
/* "4567_1234567_1234567_1234567_1234567_1234567_1234567_1234567_12 */
	);
	exit(-__LINE__);
}

/* Parse a number in decimal or hex with or without a multiplier. */

static long long interpretLength(char * arg)
{
	char unit = '\0';
	long long length = 0;
	long long multiplier = 1;
	long long Ki = 1024;

	if (0 < sscanf(arg, "0x%llX%c", &length, &unit))
		;
	else if (0 < sscanf(arg, "x%llX%c", &length, &unit))
		;
	else if (0 < sscanf(arg, "0X%llX%c", &length, &unit))
		;
	else if (0 < sscanf(arg, "X%llX%c", &length, &unit))
		;
	else if (0 < sscanf(arg, "%lld%c", &length, &unit))
		;
	else {
		exitConcise();
	}

	if (length < 0) {
		exitConcise();
	}

	switch (unit) {
		case '\0': multiplier = 1; break;
		case 'k': multiplier = Ki; break;
		case 'm': multiplier = Ki * Ki; break;
		case 'g': multiplier = Ki * Ki * Ki; break;
		case 't': multiplier = Ki * Ki * Ki * Ki; break;
		default: exitConcise();
	}

	if ((DD_LLONG_MAX / multiplier) < length) {
		fprintf(stderr, "arg %lld * %lld > LLONG_MAX = %lld\n",
			length, multiplier, DD_LLONG_MAX);
		exit(-__LINE__);
	}
	length *= multiplier;

	return length;
}

/* Interpret any option or assignment statement. */

static void interpretArg(char * arg)
{
	if (memcmp(arg, "if=", strlen("if=")) == 0) {
		ifn = &arg[strlen("if=")];
	} else if (strcmp(arg, "if") == 0) {
		ifn = NULL;
	} else if (memcmp(arg, "skip=", strlen("skip=")) == 0) {
		skip = interpretLength(&arg[strlen("skip=")]);
	} else if (memcmp(arg, "of=", strlen("of=")) == 0) {
		ofn = &arg[strlen("of=")];
	} else if (strcmp(arg, "of") == 0) {
		ofn = NULL;
	} else if (memcmp(arg, "seek=", strlen("seek=")) == 0) {
		seek = interpretLength(&arg[strlen("seek=")]);
	} else if (memcmp(arg, "bs=", strlen("bs=")) == 0) {
		bs = interpretLength(&arg[strlen("bs=")]);
	} else if (memcmp(arg, "sbs=", strlen("sbs=")) == 0) {
		sbs = interpretLength(&arg[strlen("sbs=")]);
	} else if (memcmp(arg, "count=", strlen("count=")) == 0) {
		count = interpretLength(&arg[strlen("count=")]);
	} else if (memcmp(arg, "ms=", strlen("ms=")) == 0) {
		ms = interpretLength(&arg[strlen("ms=")]);
	} else if (strcmp(arg, "--help") == 0) {
		exitVerbose();
	} else if (strcmp(arg, "--version") == 0) {
		fprintf(stderr, VERSION);
		exit(-__LINE__);
	} else if (strcmp(arg, "-f") == 0) {
		forced = 1;
	} else if (strcmp(arg, "-v") == 0) {
		verbose = 1;
	} else if (strcmp(arg, "-fv") == 0) {
		forced = 1; verbose = 1;
	} else if (strcmp(arg, "-vf") == 0) {
		verbose = 1; forced = 1;
	} else {
		exitConcise();
	}
}

/* Name the bytes to copy, die if bs exceeds INT_MAX. */

static void ionew(void)
{
	if (bs < INT_MAX) {
		chars = (char *) calloc((size_t) bs, 1);
	}
	if (chars == NULL) {
		perror("calloc");
		exit(-__LINE__);
	}
}

/* Open the input. */

static void iopen(void)
{
	if (ifn == NULL) {
		ifile = DD_NULL; /* no change */
	} else if (*ifn == '\0') {
		ifile = dd_in();
	} else {
		ifile = dd_open_rb(ifn);
	}
}

/* Close the input. */

static void iclose(void)
{
	if (ifile == DD_NULL) {
		;
	} else if (ifile == dd_in()) {
		;
	} else {
		dd_close(ifile);
	}
	ifile = DD_NULL;
}

/* Finish interpreting skip=BLOCKS. */

static void ibegin(void)
{
	long long offset = (skip * sbs);
	if ((DD_LLONG_MAX / sbs) < skip) {
		fprintf(stderr, "skip in %lld * %lld > LLONG_MAX = %lld\n",
			skip, bs, DD_LLONG_MAX);
		exit(-__LINE__);
	}
	if (ifile != DD_NULL) {
		dd_seek_set(ifile, offset);
	}
}

/* Open the output. */

static void oopen(void)
{
	if (ofn == NULL) {
		ofile = DD_NULL; /* no change */
	} else if (*ofn == '\0') {
		ofile = dd_out();
	} else {
		ofile = dd_open_wb(ofn);
	}
}

/* Close the output. */

static void oclose(void)
{
	if (ofile == DD_NULL) {
		;
	} else if (ofile == dd_out()) {
		;
	} else {
		dd_close(ofile);
	}
	ofile = DD_NULL;
}

/* Finish interpreting seek=BLOCKS. */

static void obegin(void)
{
	long long offset = (seek * sbs);
	if ((DD_LLONG_MAX / sbs) < seek) {
		fprintf(stderr, "seek out %lld * %lld > LLONG_MAX = %lld\n",
			seek, bs, DD_LLONG_MAX);
		exit(-__LINE__);
	}
	if (ofile != DD_NULL) {
		dd_seek_set(ofile, offset);
	}
}

/* Try to copy bs bytes to output from input. */

static int iocopy(void)
{
	size_t isz;
	size_t osz;
	int before = 0;

	if (0 < ms) {
		before = dd_getms();
	}

	tried += bs;

	if (ifile == DD_NULL) {
		isz = (size_t) bs;
	} else {
		isz = dd_read(chars, (size_t) bs, ifile);
	}

	if (ofile == DD_NULL) {
		osz = isz;
	} else {
		osz = dd_write(chars, isz, ofile);
	}

	copied += osz;

	if (0 < ms) {
		int after = dd_getms();
		int between = (after - before);
		int slow = (ms < between);
		int s = (between / 1000);
		int ms = (between % 1000);
		if (slow) {
			fprintf(stderr, "slow %d.%03ds\n", s, ms);
			return -__LINE__;
		}
		if (verbose) {
			fprintf(stderr, "%d.%03ds\n", s, ms);
		}
	}

	if (osz != bs) {
		return -__LINE__;
	}

	return 0;
}

/* Call iocopy repeatedly, count the bytes copied, maybe time the copies. */

static void iorun(void)
{
	long long i;

#if 0
	fprintf(stderr,
		"if=%s skip=%lld ofn=%s seek=%lld bs=%lld count=%lld\n",
		ifn, skip, ofn, seek, bs, count);
	fprintf(stderr,
		"if=%s skip=0x%llX ofn=%s seek=0x%llX bs=0x%llX count=0x%llX\n",
		ifn, skip, ofn, seek, bs, count);
#endif

	ionew();
	iopen();
	oopen();

	ibegin();
	obegin();

	for (i = 0; ((i < count) || (count < 0)); ++i) {
		if (iocopy() != 0) {
			fprintf(stderr,
				"%lld = 0x%llX bytes copied",
				copied, copied);
			if (copied < tried) {
				fprintf(stderr,
					", %lld = 0x%llX bytes tried",
					tried, tried);
			}
			fprintf(stderr, "\n");
			if (!forced) break;
		}
	}

	oclose();
	iclose();
}

/* Run from the command line. */

int main(int argc, char * argv[])
{
	int i;
	for (i = 1; i < argc; ++i) {
		interpretArg(argv[i]);
	}
	if (sbs == 0) sbs = bs;
	dd_set_verbose(verbose);
	iorun();
	return 0;
}

/* end of file */

